import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.HashMap;

public class Server {

    public static void main(String[] args) {

        RealServer realServer = new RealServer();
        realServer.main(args);


    }
}


