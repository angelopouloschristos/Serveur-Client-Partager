import java.net.Socket;

public class User {
    private String username;
    public EchoThread thread;
    public RealServer server;

    User(String u, Socket s, RealServer server2){
        this.username=u;
        this.server = server2;
        thread = new EchoThread(s, username,this.server);
        thread.start();

    }

    public String getUsername(){
        return  username;
    }

}
